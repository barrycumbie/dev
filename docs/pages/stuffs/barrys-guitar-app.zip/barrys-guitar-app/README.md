# Barry's Guitar App

2024 v1.1

====

narrative/the problem

I pick up my guitar. I don't know what play. I play the same songs over and over. I forget all the songs I know or like or want to play. I don't have a playlist of all the songs to listen to them more frequently and learn the lyrics and rhythm and fills and all. Someone asks me what can I play and I can't answer. I sit down with another muscician and we spend too long asking what each other knows or doesn't know. I've been playing for 20+ years off and on. I'm not great but not terrible like I used to be. I sometimes don't pick it up for months and months. I've got lists of songs in apps, notebooks, in open tabs, and all over the place.

test

I pick up my guitar, open up my app, and know just what to play and enjoy it a bit more. I can update the status of songs as I like them or get more solid on them. I can share the app and others can request what to play or collaborate. Others can use the same app with their account and it'll figure out what we should be playing togehter. I've got links to all the resources I need on it. It logs (and reminds me?) when and what to do for maintenance of my instruments and equipment and subscriptions.

user story / wireframe

_as a_ mediocre, but long-time guitar player
_i want_ to know what songs I can play
_so that_ I can play for and with people and remember what to play

wireframe
...todo

v/hx
1.0. CodePen
.1. Local Dev Box (.zip)
.2. GitHub / Pages

===

## Made with

love :heart:
w3cSchools
g/Chrome
vsCode
ex/ LiveServer, (emmet, todo, prettier)
config/ tabs, quotes, ...
